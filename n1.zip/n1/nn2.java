package n1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.time.DateFormatUtils;
import narou4j.Narou;
import narou4j.Ranking;
import narou4j.entities.NovelRank;
import narou4j.enums.RankingType;

public class nn2 {

	// ランキング処理
	public static void main(String[] args) {
		nn2();
	}

	public static void nn2() {
		String ncode = "n1701bm";
		String path = "C:\\temp\\test";
		String ext = ".html";

		Narou narou = new Narou();
		Ranking ranking = new Ranking();

		List<NovelRank> drList = ranking.getRanking(RankingType.DAILY);


		for (int i = 0; i < drList.size(); i++) {

	        try {

	        	Path dir = Paths.get(path, DateFormatUtils.format(new Date(), "yyyyMMdd"));

				if (!Files.exists(dir)) {
					Files.createDirectories(dir);
				}

				String w = drList.get(i).getNcode() + System.getProperty("line.separator");

				String fileName = RankingType.DAILY.name() + ".txt";

				if (!Files.exists(Paths.get(dir.toString(), fileName))) {
					Files.createFile(Paths.get(dir.toString(), fileName));
				}

	            Files.write(Paths.get(dir.toString(), fileName),
	            		w.getBytes()
	            		, StandardOpenOption.APPEND
	            );
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

		}

		System.out.println("処理が終了しました");
	}

}
