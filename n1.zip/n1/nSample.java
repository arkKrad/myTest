package n1;

public class nSample {

	public static void main(String[] args) {
//		Narou narou = new Narou();
//
//		// 小説の目次を取得
//		narou.getNovelTable(String ncode);
//
//		// 指定したページの本文を取得
//		narou.getNovelBody(String ncode, int page);
//
//		// 小説の目次と本文を取得（順番は目次順）
//		narou.getNovelBodyAll(String ncode);
//
//		// 小説の情報、目次、本文の全てを取得
//		narou.getNovelAll(String ncode);
//
//		// 指定した条件に当てはまる小説の情報、目次、本文の全てを取得（前回記事参照）
//		narou.getNovelsAll();
//
//		Ranking ranking = new Ranking();
//
//		// 指定されたランキングタイプでランキングを取得
//		ranking.getRanking(RankingType type);
//
//		// 指定されたランキングタイプで指定日時のランキングを取得
//		ranking.getRanking(RankingType type, Date date);
//
//		// 指定された小説コードの過去のランクイン情報を取得
//		ranking.getRankinDetail(String ncode);

	}

}
