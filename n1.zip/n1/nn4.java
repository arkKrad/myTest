package n1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import org.apache.commons.lang3.time.DateFormatUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import narou4j.Narou;
import narou4j.entities.Novel;
import narou4j.entities.NovelBody;
import narou4j.entities.NovelRank;
import narou4j.enums.NovelGenre;
import narou4j.enums.OfParam;
import narou4j.network.NarouApiClient;
import okhttp3.Response;

public class nn4 {

	static NarouApiClient client = new NarouApiClient();
	static Set<OfParam> ofParamSet = new HashSet();
	static Map<String, String> params = new HashMap();
	static Set<NovelGenre> novelGenreSet = new TreeSet();
	static Set<NovelGenre> notNovelGenreSet = new TreeSet();
	static Set<Integer> userIdSet = new TreeSet();
	static Set<String> ncodeSet = new TreeSet();

	static boolean isGzip = true;

	// 設定したNコードの情報を収集
	public static void main(String[] args) throws IOException {

		// 変数定義
		String ncode = "N9902BN";
		String path = "C:\\temp\\test";
		String ext = ".html";
		Narou narou = new Narou();
		String day = DateFormatUtils.format(new Date(), "yyyyMMdd");
		Path dir = Paths.get(path, DateFormatUtils.format(new Date(), "yyyyMMdd"));
		Pattern illegalFileNamePattern = Pattern.compile("[(\\|/|:|\\*|?|\"|<|>|\\\\|)]");

		int chapterCnt = 0;
		Path chapterDir = null;

		List<NovelBody> list = new ArrayList<NovelBody>();
		try {

//			setAllParams();
			params.put("gzip", String.valueOf(1));
			params.put("ncode", ncode);
			params.put("title", OfParam.TITLE.name());

			List<Novel> novels = null;
			novels = Utils.response2Json4Novel(client.getNovels(params), isGzip);

			// Nコードに紐付く情報を取得
			list = narou.getNovelTable(ncode);
		} catch (Exception e1) {
			// Nコードが死んでる場合はエラーメッセージだけ出す
			System.out.println("エラーNコード:" + ncode);
			e1.printStackTrace();
		}

		// 取得した情報の件数分ループ
		for (int i = 0; i < list.size(); i++) {
	        try {
	        	try {
	        		NovelBody body = null;
					if (list.size() > i+1) {
						// 本体情報を取得
						body = narou.getNovelBody(ncode, i+1);
					}

					// 本体情報が存在しているかチェック
					if (body.getBody() != null) {
						// 本体情報を設定
						list.get(i).setBody(body.getBody());
					} else {
						// 存在していないなら次へ
						continue;
					}
				} catch (Exception e) {
					// ここまでで何かエラーの場合は次へ
					continue;
				}

	        	// フォルダ用のパス作成
	        	dir = Paths.get(path, day, ncode);

	        	// パス先が存在しない場合
				if (!Files.exists(dir)) {
					// フォルダを作る
					Files.createDirectories(dir);
				}

				// チャプター設定が正しくされている場合
				if (list.get(i).getPage() == 0 && list.get(i).isChapter()) {
					// チャプターカウントを加算
					chapterCnt = chapterCnt + 1;

					// チャプターフォルダを作成
					chapterDir = Paths.get(dir.toString(), chapterCnt + "." + list.get(i).getTitle());

		        	// パス先が存在しない場合
					if (!Files.exists(chapterDir)) {
						// フォルダを作る
						Files.createDirectories(chapterDir);

						// チャプターの場合はここで次へ飛ばす
						continue;
					}
				}

				// ファイル名作成
				String fileName = list.get(i).getPage() + "_"
						+ list.get(i).getTitle() + ext;

				// チャプターカウントがある場合
				if (chapterCnt > 0) {
					// 書き込み先を書き換える
					dir = chapterDir;
				}

				// ファイルに使えない文字を対象にハイフンに変換
				fileName = illegalFileNamePattern.matcher(fileName).replaceAll("-");

				// 書き込み
	            Files.write(Paths.get(dir.toString(), fileName),
	            list.get(i).getBody().getBytes()
//		            Charset.forName("UTF-8"),
//		            , StandardOpenOption.TRUNCATE_EXISTING
	            );
	        } catch (Exception e) {
	        	// 何等かのエラーの場合はエラーメッセージを出して次へ
	            e.printStackTrace();
	            continue;
	        }

		}

		System.out.println("処理が終了しました");

	}

	public static 	String getOfParam() {
		StringBuilder builder = new StringBuilder();

		int i = 1;
		for (OfParam pm : ofParamSet) {
			builder.append(pm.getId());
			if (i != ofParamSet.size()) {
				builder.append("-");
			}
			i++;
		}
		return builder.toString();
	}

	public static void setAllParams() {
		if (!isSetEmpty(ofParamSet)) {
			params.put("of", getOfParam());
		}
		if (!isSetEmpty(novelGenreSet)) {
			params.put("genre", getGenre());
		}
		if (!isSetEmpty(notNovelGenreSet)) {
			params.put("notgenre", getNotGenre());
		}
		if (!isSetEmpty(userIdSet)) {
			params.put("userid", getUserIds());
		}
		if (!isSetEmpty(ncodeSet)) {
			params.put("ncode", getNcodes());
		}
	}

	static boolean isSetEmpty(Set set) {
		return set.size() <= 0;
	}

	static String getGenre() {
		return genre2String(novelGenreSet);
	}

	static String getNotGenre() {
		return genre2String(notNovelGenreSet);
	}

	static String genre2String(Set<NovelGenre> set) {
		StringBuilder builder = new StringBuilder();

		int i = 1;
		for (NovelGenre novelGenre : set) {
			builder.append(novelGenre.getId());
			if (i != set.size()) {
				builder.append("-");
			}
			i++;
		}
		return builder.toString();
	}

	static String getUserIds() {
		StringBuilder builder = new StringBuilder();

		int i = 1;
		for (Iterator localIterator = userIdSet.iterator(); localIterator.hasNext();) {
			int userId = ((Integer) localIterator.next()).intValue();
			builder.append(userId);
			if (i != userIdSet.size()) {
				builder.append("-");
			}
			i++;
		}
		return builder.toString();
	}

	static String getNcodes() {
		StringBuilder builder = new StringBuilder();

		int i = 1;
		for (String ncode : ncodeSet) {
			builder.append(ncode);
			if (i != ncodeSet.size()) {
				builder.append("-");
			}
			i++;
		}
		return builder.toString();
	}


}

class Utils {
	Utils() {}

	static List<Novel> response2Json4Novel(Response response, boolean isGzip) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		String str = getBodyString(response, isGzip);

		String sstr = str.substring(str.indexOf("title"), str.indexOf("ncode"));

		List<Novel> novels = null;
		try {
//			novels = (List) mapper.readValue(str, new TypeReference() {});
			novels = (List) mapper.readValue(sstr, new TypeReference<List<Novel>>(){});
		} catch (IOException e) {
			e.printStackTrace();
		}
		return novels;
	}

	static List<NovelRank> response2Json4Ranking(Response response, boolean isGzip)
			throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		String str = getBodyString(response, isGzip);

		List<NovelRank> rankings = null;
		try {
			rankings = (List) mapper.readValue(str, new TypeReference() {});
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rankings;
	}

	private static String getBodyString(Response response, boolean isGzip) throws IOException {
		if (isGzip) {
			BufferedReader br = new BufferedReader(
					new InputStreamReader(new GZIPInputStream(response.body().byteStream())));
			Throwable localThrowable3 = null;
			try {
				StringBuilder builder = new StringBuilder();
				String line;
				while ((line = br.readLine()) != null) {
					builder.append(line);
				}
				return builder.toString();
			} catch (Throwable localThrowable1) {
				localThrowable3 = localThrowable1;
				throw localThrowable1;
			} finally {
				if (br != null) {
					if (localThrowable3 != null) {
						try {
							br.close();
						} catch (Throwable localThrowable2) {
							localThrowable3.addSuppressed(localThrowable2);
						}
					} else {
						br.close();
					}
				}
			}
		}
		return response.body().string();
	}

	static String day2ThuesDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeZone(TimeZone.getTimeZone("Asia/Tokyo"));
		calendar.setTime(date);

		int week = calendar.get(7);
		if ((week == 2) || (week == 1)) {
			week += 7;
		}
		calendar.add(5, -week);
		calendar.add(5, 3);
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		return format.format(calendar.getTime());
	}

	static String day2MonthOne(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeZone(TimeZone.getTimeZone("Asia/Tokyo"));
		calendar.setTime(date);

		int day = calendar.get(5);
		calendar.add(5, -day + 1);
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		return format.format(calendar.getTime());
	}
}

