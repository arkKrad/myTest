package n1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.commons.lang3.time.DateFormatUtils;
import narou4j.Narou;
import narou4j.entities.NovelBody;
import narou4j.enums.RankingType;

public class nn3 {

	// 日のランキングのNコードから全部収集
	public static void main(String[] args) throws IOException {

		// 変数定義
		String ncode = "";
		String path = "C:\\temp\\test";
		String ext = ".html";
		Narou narou = new Narou();
		Path Basedir = Paths.get(path, DateFormatUtils.format(new Date(), "yyyyMMdd"));
		Path dir = Paths.get(path, DateFormatUtils.format(new Date(), "yyyyMMdd"));
		String readFile = RankingType.DAILY.name() + ".txt";
		Pattern illegalFileNamePattern = Pattern.compile("[(\\|/|:|\\*|?|\"|<|>|\\\\|)]");

		// ランキングファイルの読み込み （デフォルトは当日）
		List<String> nCodeList =  new ArrayList<String>();

		// 読み込むファイルの存在確認
		if (!Files.exists(Paths.get(dir.toString(), readFile))) {
			System.out.println("ファイルが読み込めませんでした");
			return;
		} else {
			nCodeList = Files.readAllLines(Paths.get(dir.toString(), readFile));
		}

		// 読み込んだランキングのNコードリストをループ
		for (int n = 0; n < nCodeList.size(); n++) {
			int chapterCnt = 0;
			Path chapterDir = null;
			ncode = nCodeList.get(n);

			List<NovelBody> list = new ArrayList<NovelBody>();
			try {
				// Nコードに紐付く情報を取得
				list = narou.getNovelTable(ncode);
			} catch (Exception e1) {
				// Nコードが死んでる場合はエラーメッセージだけ出して次へ
				System.out.println("エラーNコード:" + ncode);
				e1.printStackTrace();
				continue;
			}

			// 取得した情報の件数分ループ
			for (int i = 0; i < list.size() + 1; i++) {
		        try {
		        	try {
		        		NovelBody body = null;
						if (list.size() > i+1) {
							// 本体情報を取得
							body = narou.getNovelBody(ncode, i+1);
						}

						// 本体情報が存在しているかチェック
						if (body.getBody() != null) {
							// 本体情報を設定
							list.get(i).setBody(body.getBody());
						} else {
							// 存在していないなら次へ
							continue;
						}
					} catch (Exception e) {
						// ここまでで何かエラーの場合は次へ
						continue;
					}

		        	// フォルダ用のパス作成
		        	dir = Paths.get(Basedir.toString(),  ncode);

		        	// パス先が存在しない場合
					if (!Files.exists(dir)) {
						// フォルダを作る
						Files.createDirectories(dir);
					}

					// チャプター設定が正しくされている場合
					if (list.get(i).getPage() == 0 && list.get(i).isChapter()) {
						// チャプターカウントを加算
						chapterCnt = chapterCnt + 1;

						// チャプターフォルダを作成
						chapterDir = Paths.get(dir.toString(), chapterCnt + "." + list.get(i).getTitle());

			        	// パス先が存在しない場合
						if (!Files.exists(chapterDir)) {
							// フォルダを作る
							Files.createDirectories(chapterDir);

							// チャプターの場合はここで次へ飛ばす
							continue;
						}
					}

					// ファイル名作成
					String fileName = list.get(i).getPage() + "_"
							+ list.get(i).getTitle() + ext;

					// チャプターカウントがある場合
					if (chapterCnt > 0) {
						// 書き込み先を書き換える
						dir = chapterDir;
					}

					// ファイルに使えない文字を対象にハイフンに変換
					fileName = illegalFileNamePattern.matcher(fileName).replaceAll("-");

					// 書き込み
		            Files.write(Paths.get(dir.toString(), fileName),
		            list.get(i).getBody().getBytes()
//		            Charset.forName("UTF-8"),
//		            , StandardOpenOption.TRUNCATE_EXISTING
		            );
		        } catch (Exception e) {
		        	// 何等かのエラーの場合はエラーメッセージを出して次へ
		            e.printStackTrace();
		            continue;
		        }

			}
		}

		System.out.println("処理が終了しました");

	}

}
